from ..cli import welcome_user


def print_welcome():
    print('Welcome to the Brain Games!')


def main():
    print_welcome()
    welcome_user()


if __name__ == '__main__':
    main()
