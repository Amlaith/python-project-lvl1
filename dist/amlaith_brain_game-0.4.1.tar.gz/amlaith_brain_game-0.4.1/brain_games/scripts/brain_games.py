from ..cli import welcome_user, print_welcome


def main():
    print_welcome()
    welcome_user()


if __name__ == '__main__':
    main()
